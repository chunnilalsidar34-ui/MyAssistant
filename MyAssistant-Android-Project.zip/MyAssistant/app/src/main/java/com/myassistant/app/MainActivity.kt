package com.myassistant.app

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.view.Gravity
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : Activity(), TextToSpeech.OnInitListener {

    private lateinit var input: EditText
    private lateinit var chat: TextView
    private lateinit var tts: TextToSpeech
    private var recognizer: SpeechRecognizer? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        tts = TextToSpeech(this, this)

        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24, 24, 24, 24)
        }

        val title = TextView(this).apply {
            text = "MyAssistant"
            textSize = 28f
            gravity = Gravity.CENTER
        }

        chat = TextView(this).apply {
            text = "नमस्ते! मैं MyAssistant हूँ।\nआप मुझसे बात कर सकते हैं।\n\n"
            textSize = 18f
            setPadding(0, 24, 0, 24)
        }

        input = EditText(this).apply {
            hint = "यहाँ लिखें..."
            textSize = 17f
        }

        val send = Button(this).apply {
            text = "Send"
            setOnClickListener {
                val text = input.text.toString().trim()
                if (text.isNotEmpty()) {
                    respond(text)
                    input.text.clear()
                }
            }
        }

        val mic = Button(this).apply {
            text = "🎤 बोलें"
            setOnClickListener { startVoiceInput() }
        }

        layout.addView(title)
        layout.addView(chat, LinearLayout.LayoutParams(-1, 0, 1f))
        layout.addView(input)
        layout.addView(send)
        layout.addView(mic)

        setContentView(layout)
    }

    private fun respond(text: String) {
        chat.append("आप: $text\n")
        val lower = text.lowercase(Locale.getDefault())

        val reply = when {
            "time" in lower || "समय" in text || "टाइम" in text -> {
                val time = SimpleDateFormat("hh:mm a", Locale.getDefault()).format(Date())
                "अभी समय $time है।"
            }
            "hello" in lower || "hi" in lower || "नमस्ते" in text || "हेलो" in text -> {
                "नमस्ते! बताइए, मैं आपकी क्या मदद करूँ?"
            }
            "who are you" in lower || "तुम कौन" in text -> {
                "मैं आपका MyAssistant हूँ।"
            }
            "joke" in lower || "चुटकुला" in text -> {
                "टीचर: सबसे ज्यादा नशा किस चीज में होता है?\nछात्र: किताबों में, खोलते ही नींद आ जाती है!"
            }
            else -> "आपने कहा: $text"
        }

        chat.append("MyAssistant: $reply\n\n")
        speak(reply)
    }

    private fun speak(text: String) {
        if (::tts.isInitialized) {
            tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, "assistant")
        }
    }

    private fun startVoiceInput() {
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 100)
            return
        }

        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            chat.append("MyAssistant: इस फोन में voice recognition उपलब्ध नहीं है।\n\n")
            return
        }

        recognizer?.destroy()
        recognizer = SpeechRecognizer.createSpeechRecognizer(this)
        recognizer?.setRecognitionListener(object : RecognitionListener {
            override fun onResults(results: Bundle?) {
                val text = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                    ?.firstOrNull() ?: return
                input.setText(text)
                respond(text)
                input.text.clear()
            }
            override fun onReadyForSpeech(params: Bundle?) {}
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(rmsdB: Float) {}
            override fun onBufferReceived(buffer: ByteArray?) {}
            override fun onEndOfSpeech() {}
            override fun onError(error: Int) {}
            override fun onPartialResults(partialResults: Bundle?) {}
            override fun onEvent(eventType: Int, params: Bundle?) {}
        })

        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "hi-IN")
            putExtra(RecognizerIntent.EXTRA_PROMPT, "बोलिए...")
        }
        recognizer?.startListening(intent)
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            tts.language = Locale("hi", "IN")
        }
    }

    override fun onDestroy() {
        recognizer?.destroy()
        tts.stop()
        tts.shutdown()
        super.onDestroy()
    }
}
