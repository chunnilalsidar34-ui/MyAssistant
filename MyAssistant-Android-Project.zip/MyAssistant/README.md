# MyAssistant

A simple Android assistant project.

Features:
- Hindi/English text chat
- Voice input using Android SpeechRecognizer
- Voice replies using Android TextToSpeech
- Current time command
- Basic offline responses

Open the project in Android Studio and run the `app` module.
